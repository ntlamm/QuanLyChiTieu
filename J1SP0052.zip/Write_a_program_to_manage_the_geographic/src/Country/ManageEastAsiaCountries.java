/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Country;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author 03623
 */
public class ManageEastAsiaCountries {
        
    public void menu() { // In Menu
        System.out.println("1. Enter the information for 11 countries in Southeast Asia.");
        System.out.println("2. Display already information.");
        System.out.println("3. Search the country according to the entered country's name.");
        System.out.println("4. Display the information increasing with the country name.");
        System.out.println("5. Exit.");
    }
    
    public int getchoice(String mess){// check input choice
        int choice;
        System.out.print(mess);
        Scanner sc = new Scanner(System.in);
        while (true) {            
            try {
                choice = Integer.parseInt(sc.nextLine());
                if(choice>=1 && choice <= 5){
                    break;
                }else{
                    System.out.println("Input integer 1-5 please!");
                    System.out.print(mess);
                }
            } catch (Exception e) {
                System.out.println("Input integer 1-5 please!");
                System.out.print(mess);
            }
        }
        return choice;
    }

//  case 1: input data country.(code, name, area, terrain)
    public String getText(String mess) { // input String có null ko.
        String txt;// input.
        System.out.print(mess);
        while (true) {
            Scanner sc = new Scanner(System.in);
            txt = sc.nextLine();
            if (txt.trim().isEmpty()) {//trim de cat dau cach thua o dau va cuoi và check rỗng hay ko
                System.out.print("Can not null, please input again: ");
            } else {
                break;
            }
        }
        return txt;
    }    
    
    public int checkExits(List<EastAsiaCountries> list, String code) { // check code input có bị trùng trong list ko
        for (EastAsiaCountries o : list) {
            if (o.getCountryCode().equals(code)) {
                return 1;
            }
        }
        return 0;
    }
    
    public float getArea(String mess) { // check input Area(float) 
        float area; // float input.
        System.out.print(mess);
        Scanner sc = new Scanner(System.in);
        while (true) {
            try {
                area = Float.parseFloat(sc.nextLine());
                break;
            } catch (Exception e) {
                System.out.print("Invalid float, please input again: ");
            }
        }
        return area;
    }    
    
    

// Case 3: search name country in list.
    public void search(List<EastAsiaCountries> list, String txt) { // search name country in list.
        int count = 0;
        for (EastAsiaCountries o : list) {
            if (o.getCountryName().equals(txt)) {
                count++;
                System.out.println("ID\tName\t\tTotal Area\tTerrain");
                o.display();
                break;
            }
        }
        if (count == 0) {
            System.out.println("Not found!");
        }
    }

// Case 4: Display all country tăng dần theo name.
    public void printList(List<EastAsiaCountries> list) {// sap xep list tăng dần theo name
        Collections.sort(list, new Comparator<EastAsiaCountries>() {
            @Override
            public int compare(EastAsiaCountries o1, EastAsiaCountries o2) {
                return o1.getCountryName().compareToIgnoreCase(o2.getCountryName());
            }
        });
        System.out.println("ID\tName\t\tTotal Area\tTerrain");
        for (EastAsiaCountries o : list) {
            o.display();
        }
    }
    
        public static void main(String[] args) {
            
        // In menu    
        ManageEastAsiaCountries m = new ManageEastAsiaCountries();
        m.menu();
        
        
        Scanner sc = new Scanner(System.in);
        EastAsiaCountries east = null; // object chứa data country input mới nhất.
        List<EastAsiaCountries> list = new ArrayList<>();// list chứa tất cả data các country.
        while (true) {
            int choice = m.getchoice("Input your choice: ");
            switch (choice) {
                case 1: //input data country.
                    String code;
                    while (true) {
                        code = m.getText("Enter code of country: ");
                        if (m.checkExits(list, code) == 0) { // 0 là khác 1 là trùng
                            break;
                        } else {
                            System.out.println("Code is exits, please input again: ");
                        }
                    }
                    String name = m.getText("Enter name of country: ");
                    float area = m.getArea("Enter total area: ");
                    String terrain = m.getText("Enter terrain of country: ");
                    east = new EastAsiaCountries(terrain, code, name, area);
                    list.add(east); // add data vào list.
                    break;
                case 2: // display data country mới nhất.
                    if(east==null){
                        System.out.println("No data!");
                    }else{
                        System.out.println("ID\tName\t\tTotal Area\tTerrain");
                        east.display();
                    }
                    break;
                case 3: // search data theo name country.
                    String txt = m.getText("Enter the name you want to search for: ");
                    m.search(list, txt);
                    break;
                case 4: // Display all country tăng dần theo name. 
                    m.printList(list);
                    break;
                case 5:
                    // Exit.
                    System.exit(0);
                    break;
            }
        }
    }
}
