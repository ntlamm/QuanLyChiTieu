/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Country;

/**
 *
 * @author 03623
 */
public class EastAsiaCountries extends Country {
// phát triển class EastAsiaCountries kế thừa class Country và thêm thuộc tính
    
    private String countryTerrain;

// Implement constructor parameter and use the super keyword to call the constructor of the class Country above. 
    public EastAsiaCountries() {
    }

    public EastAsiaCountries(String countryTerrain, String countryCode, String countryName, float totalArea) {
        super(countryCode, countryName, totalArea);
        this.countryTerrain = countryTerrain;
    }
    
// Override  display().
    @Override
    public void display(){
        super.display();
        System.out.println("\t"+countryTerrain);
    } 
    
}
